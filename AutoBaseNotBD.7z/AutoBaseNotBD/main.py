from flask import Flask, request, jsonify
import os

app = Flask(__name__)

# Класс для работы с данными об автомобилях
class CarDataManager:
    def __init__(self, file_name):
        self.file_name = file_name
        if not os.path.exists(file_name):
            # Создаем файл, если он не существует
            file = open(file_name, 'w')
            file.close()

    def read_data(self):
        file = open(self.file_name, 'r')
        data = file.readlines()
        file.close()
        result = []
        for line in data:
            result.append(line.strip())
        return result

    def write_data(self, car_data):
        file = open(self.file_name, 'a')
        file.write(f"{car_data['brand']},{car_data['model']},{car_data['drivetrain']},{car_data['engine_capacity']},{car_data['steering_wheel']}\n")
        file.close()

# Создаем объект для управления данными
car_data_manager = CarDataManager("cars_data.txt")

@app.route('/add_car', methods=['POST'])
def add_car():
    if not request.is_json:
        return jsonify({"error": "Request must be JSON"}), 400

    car_data = request.get_json()
    if 'brand' not in car_data or 'model' not in car_data or 'drivetrain' not in car_data or 'engine_capacity' not in car_data or 'steering_wheel' not in car_data:
        return jsonify({"error": "Missing one or more required fields"}), 400

    car_data_manager.write_data(car_data)
    return jsonify({"message": "Car data added successfully"}), 200

@app.route('/get_cars', methods=['GET'])
def get_cars():
    cars = car_data_manager.read_data()
    car_list = []
    for car in cars:
        parts = car.split(',')
        car_list.append({
            "brand": parts[0],
            "model": parts[1],
            "drivetrain": parts[2],
            "engine_capacity": parts[3],
            "steering_wheel": parts[4]
        })
    return jsonify({"cars": car_list}), 200

if __name__ == '__main__':
    app.run(debug=True)